
// Simple i18n dictionary
const DICT = {
  en: {
    nav_home: "Home",
    nav_maps: "Maps",
    nav_weapons: "Weapons",
    nav_cross: "Crosshair & Viewmodel",
    hero_title: "CS2 Community Guide",
    hero_sub: "Maps, smokes, weapons, and customization — clean and fast.",
    maps_title: "Maps & Smokes",
    weapons_title: "Weapons (key stats)",
    cross_title: "Crosshair & Viewmodel",
    videos_title: "Smoke Tutorials (YouTube embeds)"
  },
  sv: {
    nav_home: "Start",
    nav_maps: "Kartor",
    nav_weapons: "Vapen",
    nav_cross: "Crosshair & Viewmodel",
    hero_title: "CS2 — Svensk Guide",
    hero_sub: "Kartor, smokes, vapen och anpassning — stilrent och snabbt.",
    maps_title: "Kartor & smokes",
    weapons_title: "Vapen (nyckelstats)",
    cross_title: "Crosshair & Viewmodel",
    videos_title: "Smoke-tutorials (YouTube)"
  }
};
let lang = localStorage.getItem("lang") || "en";
function setLang(l){
  lang=l; localStorage.setItem("lang", l);
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const k=el.getAttribute("data-i18n"); el.textContent = (DICT[l]&&DICT[l][k])||el.textContent;
  });
  document.documentElement.lang=l;
}
document.addEventListener("DOMContentLoaded",()=>{
  setLang(lang);
  document.querySelectorAll("[data-lang]").forEach(btn=>btn.addEventListener("click",()=>setLang(btn.dataset.lang)));
  // Accordion
  document.querySelectorAll(".accordion .head").forEach(head=>{
    head.addEventListener("click",()=> head.parentElement.classList.toggle("open"));
  });
  // Tabs (maps)
  const tabs = document.querySelectorAll("[data-tab]");
  const panels = document.querySelectorAll("[data-panel]");
  tabs.forEach(t=>t.addEventListener("click",()=>{
    tabs.forEach(x=>x.classList.remove("active"));
    t.classList.add("active");
    panels.forEach(p=>p.style.display = (p.dataset.panel===t.dataset.tab)?"block":"none");
  }));
  if(tabs[0]) tabs[0].click();

  // Zoom & pan
  document.querySelectorAll(".zoomwrap").forEach(wrap=>{
    const img = wrap.querySelector("img");
    let scale=1, ox=0, oy=0, drag=false, sx=0, sy=0;
    const apply=()=>{ img.style.transform = `translate(${ox}px, ${oy}px) scale(${scale})`; };
    wrap.addEventListener("wheel",(e)=>{
      e.preventDefault();
      const delta = e.deltaY>0 ? -0.1 : 0.1;
      const old=scale; scale = Math.max(1, Math.min(4, scale+delta));
      // Zoom towards cursor
      const rect = img.getBoundingClientRect();
      const cx = e.clientX - rect.left, cy = e.clientY - rect.top;
      ox = cx - (cx - ox) * (scale/old);
      oy = cy - (cy - oy) * (scale/old);
      apply();
    }, {passive:false});
    wrap.addEventListener("mousedown",(e)=>{ drag=true; sx=e.clientX; sy=e.clientY; wrap.style.cursor="grabbing"; });
    window.addEventListener("mouseup",()=>{ drag=false; wrap.style.cursor="default"; });
    window.addEventListener("mousemove",(e)=>{
      if(!drag) return;
      ox += e.clientX - sx; oy += e.clientY - sy; sx=e.clientX; sy=e.clientY; apply();
    });
    wrap.querySelector(".zoom-in").addEventListener("click",()=>{ scale=Math.min(4,scale+0.25); apply(); });
    wrap.querySelector(".zoom-out").addEventListener("click",()=>{ scale=Math.max(1,scale-0.25); apply(); });
    wrap.querySelector(".zoom-1").addEventListener("click",()=>{ scale=1; ox=0; oy=0; apply(); });
    apply();
  });
});
